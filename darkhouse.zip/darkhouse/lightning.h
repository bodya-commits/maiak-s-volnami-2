#pragma once
#include <glad/glad.h>
#include "vec.h"

class Lightning {
public:
    static const int POINTS = 14;

    float flash = 0.0f;
    float age = 100.0f;
    Vec3 direction{0.0f, 1.0f, 0.0f};

    void update(float t, Vec3 camera) {
        if (t >= nextFlash) {
            start = t;
            nextFlash = t + 2.5f + rnd01() * 6.0f;
            float a = rnd01() * 2.0f * PI;
            float r = 70.0f + rnd01() * 50.0f;
            spawn(camera, {std::cos(a) * r, 0.0f, std::sin(a) * r});
        }
        age = t - start;
        flash = 0.0f;
        if (age >= 0.0f && age < 1.5f) {
            flash = std::exp(-age * 9.0f);
            if (age > 0.18f) {
                float second = 0.8f * std::exp(-(age - 0.18f) * 11.0f);
                flash = flash > second ? flash : second;
            }
        }
    }

    void strike(float t, Vec3 camera, Vec3 target) {
        start = t;
        if (nextFlash < t + 1.5f) {
            nextFlash = t + 1.5f;
        }
        spawn(camera, target);
    }

    bool boltVisible() const {
        return age < 0.4f && flash > 0.05f;
    }

    void drawBolt() const {
        float k = 0.4f + 0.6f * flash;
        glColor4f(0.85f * k, 0.9f * k, 1.0f * k, 1.0f);
        glBegin(GL_TRIANGLE_STRIP);
        for (int i = 0; i < POINTS * 2; i++) {
            glVertex3f(bolt[i].x, bolt[i].y, bolt[i].z);
        }
        glEnd();
    }

private:
    float start = -100.0f;
    float nextFlash = 3.0f;
    Vec3 bolt[POINTS * 2];

    void spawn(Vec3 camera, Vec3 target) {
        const float top = 80.0f;
        direction = normalize({target.x, 40.0f, target.z});
        Vec3 toCam = normalize({camera.x - target.x, 0.0f, camera.z - target.z});
        Vec3 sideDir = normalize(cross({0.0f, 1.0f, 0.0f}, toCam));
        float dist = length(camera - target);
        float ratio = dist / 80.0f;
        float width = 0.15f + 0.25f * (ratio < 1.0f ? ratio : 1.0f);
        Vec3 side = sideDir * width;
        float wx = 0.0f;
        float wz = 0.0f;
        for (int i = 0; i < POINTS; i++) {
            float frac = i / (float)(POINTS - 1);
            float y = top + (target.y - top) * frac;
            wx += (rnd01() - 0.5f) * 8.0f;
            wz += (rnd01() - 0.5f) * 8.0f;
            float px = target.x + wx * (1.0f - frac);
            float pz = target.z + wz * (1.0f - frac);
            bolt[i * 2] = {px - side.x, y, pz - side.z};
            bolt[i * 2 + 1] = {px + side.x, y, pz + side.z};
        }
    }
};
