#pragma once
#include <algorithm>
#include <vector>
#include <glad/glad.h>
#include "vec.h"

class Rocks {
public:
    static constexpr float EXTENT = 17.0f;

    Rocks() {
        int n = 72;
        float step = 2.0f * EXTENT / n;
        float e = 0.2f;
        for (int j = 0; j <= n; j++) {
            for (int i = 0; i <= n; i++) {
                float x = -EXTENT + i * step;
                float z = -EXTENT + j * step;
                float y = height(x, z);
                float nx = (height(x - e, z) - height(x + e, z)) / (2.0f * e);
                float nz = (height(x, z - e) - height(x, z + e)) / (2.0f * e);
                Vec3 nrm = normalize({nx, 1.0f, nz});
                float k = 0.5f + 0.5f * std::sin(x * 2.1f) * std::cos(z * 1.7f);
                float shade = (0.6f + 0.4f * k) * (0.6f + 0.4f * nrm.y);
                float vals[9] = {x, y, z, nrm.x, nrm.y, nrm.z, 0.30f * shade, 0.27f * shade, 0.24f * shade};
                for (int q = 0; q < 3; q++) {
                    positions.push_back(vals[q]);
                    normals.push_back(vals[3 + q]);
                    colors.push_back(vals[6 + q]);
                }
            }
        }
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < n; i++) {
                unsigned int a = j * (n + 1) + i;
                unsigned int b = a + 1;
                unsigned int c = a + n + 1;
                unsigned int d = c + 1;
                indices.push_back(a);
                indices.push_back(c);
                indices.push_back(b);
                indices.push_back(b);
                indices.push_back(c);
                indices.push_back(d);
            }
        }
    }

    static float groundHeight(float x, float z) {
        return height(x, z);
    }

    void draw() const {
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_NORMAL_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        glVertexPointer(3, GL_FLOAT, 0, positions.data());
        glNormalPointer(GL_FLOAT, 0, normals.data());
        glColorPointer(3, GL_FLOAT, 0, colors.data());
        glDrawElements(GL_TRIANGLES, (GLsizei)indices.size(), GL_UNSIGNED_INT, indices.data());
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_NORMAL_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);
    }

private:
    std::vector<float> positions;
    std::vector<float> normals;
    std::vector<float> colors;
    std::vector<unsigned int> indices;

    static float height(float x, float z) {
        float r = std::sqrt(x * x + z * z);
        float t = std::max(0.0f, 1.0f - r / EXTENT);
        float h = 9.5f * std::pow(t, 1.2f) - 3.0f;
        float n = 0.9f * std::sin(x * 0.6f + 1.0f) * std::cos(z * 0.5f)
                + 0.5f * std::sin(x * 1.7f + z * 1.3f)
                + 0.3f * std::sin(z * 2.9f - x * 2.3f);
        h += n * std::min(1.0f, t * 3.0f);
        float k = smoothstep(2.5f, 5.0f, r);
        return 4.5f * (1.0f - k) + h * k;
    }
};
