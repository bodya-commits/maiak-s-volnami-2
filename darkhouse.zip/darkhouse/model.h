#pragma once
#include <fstream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include <glad/glad.h>
#include "vec.h"

class Model {
public:
    bool load(const std::string& path) {
        std::ifstream in(path);
        if (!in) {
            return false;
        }
        std::vector<Vec3> v;
        std::vector<Vec3> vc;
        std::vector<Vec3> vn;
        std::string line;
        while (std::getline(in, line)) {
            std::istringstream ss(line);
            std::string tag;
            ss >> tag;
            if (tag == "v") {
                float x, y, z;
                ss >> x >> y >> z;
                float r, g, b;
                if (ss >> r >> g >> b) {
                    vc.push_back({r, g, b});
                } else {
                    vc.push_back({0.7f, 0.7f, 0.7f});
                }
                v.push_back({x, y, z});
            } else if (tag == "vn") {
                float x, y, z;
                ss >> x >> y >> z;
                vn.push_back({x, y, z});
            } else if (tag == "f") {
                std::vector<std::pair<int, int>> face;
                std::string tok;
                while (ss >> tok) {
                    int vi = 0;
                    int ni = 0;
                    size_t s1 = tok.find('/');
                    vi = std::stoi(tok.substr(0, s1));
                    if (s1 != std::string::npos) {
                        size_t s2 = tok.find('/', s1 + 1);
                        if (s2 != std::string::npos && s2 + 1 < tok.size()) {
                            ni = std::stoi(tok.substr(s2 + 1));
                        }
                    }
                    face.push_back({vi, ni});
                }
                for (size_t k = 1; k + 1 < face.size(); k++) {
                    addVertex(v, vc, vn, face[0], face[k], face[k + 1], 0);
                    addVertex(v, vc, vn, face[0], face[k], face[k + 1], 1);
                    addVertex(v, vc, vn, face[0], face[k], face[k + 1], 2);
                }
            }
        }
        return !positions.empty();
    }

    void draw() const {
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_NORMAL_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        glVertexPointer(3, GL_FLOAT, 0, positions.data());
        glNormalPointer(GL_FLOAT, 0, normals.data());
        glColorPointer(3, GL_FLOAT, 0, colors.data());
        glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(positions.size() / 3));
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_NORMAL_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);
    }

private:
    std::vector<float> positions;
    std::vector<float> normals;
    std::vector<float> colors;

    void addVertex(const std::vector<Vec3>& v, const std::vector<Vec3>& vc, const std::vector<Vec3>& vn,
                   std::pair<int, int> a, std::pair<int, int> b, std::pair<int, int> c, int which) {
        std::pair<int, int> ids[3] = {a, b, c};
        std::pair<int, int> id = ids[which];
        Vec3 p = v[id.first - 1];
        Vec3 col = vc[id.first - 1];
        Vec3 n;
        if (id.second > 0) {
            n = vn[id.second - 1];
        } else {
            Vec3 pa = v[a.first - 1];
            Vec3 pb = v[b.first - 1];
            Vec3 pc = v[c.first - 1];
            n = normalize(cross(pb - pa, pc - pa));
        }
        positions.push_back(p.x);
        positions.push_back(p.y);
        positions.push_back(p.z);
        normals.push_back(n.x);
        normals.push_back(n.y);
        normals.push_back(n.z);
        colors.push_back(col.x);
        colors.push_back(col.y);
        colors.push_back(col.z);
    }
};
