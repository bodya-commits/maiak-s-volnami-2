#pragma once
#include <glad/glad.h>
#include "vec.h"

namespace Lighthouse {

const float BASE = 4.3f;
const float HEIGHT = 14.0f;
const float LANTERN_Y = BASE + HEIGHT + 0.35f + 0.8f;

inline float radiusAt(float y) {
    return 2.2f - 0.7f * y / HEIGHT;
}

inline void drawFrustum(float cy, float r0, float r1, float h, int seg,
                        float cr, float cg, float cb, bool capTop) {
    glColor3f(cr, cg, cb);
    glBegin(GL_QUAD_STRIP);
    for (int i = 0; i <= seg; i++) {
        float a = 2.0f * PI * i / seg;
        float ca = std::cos(a);
        float sa = std::sin(a);
        Vec3 n = normalize({ca * h, r0 - r1, sa * h});
        glNormal3f(n.x, n.y, n.z);
        glVertex3f(r0 * ca, cy, r0 * sa);
        glVertex3f(r1 * ca, cy + h, r1 * sa);
    }
    glEnd();
    if (capTop) {
        glNormal3f(0.0f, 1.0f, 0.0f);
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(0.0f, cy + h, 0.0f);
        for (int i = 0; i <= seg; i++) {
            float a = 2.0f * PI * i / seg;
            glVertex3f(r1 * std::cos(a), cy + h, r1 * std::sin(a));
        }
        glEnd();
    }
}

inline void drawBody() {
    int parts = 5;
    float h = HEIGHT / parts;
    for (int i = 0; i < parts; i++) {
        float y0 = i * h;
        float y1 = y0 + h;
        if (i % 2 == 0) {
            drawFrustum(BASE + y0, radiusAt(y0), radiusAt(y1), h, 28, 0.72f, 0.09f, 0.07f, false);
        } else {
            drawFrustum(BASE + y0, radiusAt(y0), radiusAt(y1), h, 28, 0.88f, 0.88f, 0.85f, false);
        }
    }
    float top = BASE + HEIGHT;
    drawFrustum(top, 2.1f, 2.1f, 0.35f, 28, 0.12f, 0.12f, 0.14f, true);
    drawFrustum(top + 0.35f + 1.6f, 1.3f, 0.1f, 1.1f, 28, 0.72f, 0.09f, 0.07f, false);
}

inline void drawLantern() {
    float top = BASE + HEIGHT;
    drawFrustum(top + 0.35f, 1.0f, 1.0f, 1.6f, 24, 1.0f, 0.95f, 0.7f, true);
}

inline void drawBeam(float length, float radius, int seg) {
    glBegin(GL_TRIANGLE_FAN);
    glColor4f(1.0f, 0.93f, 0.7f, 0.06f);
    glVertex3f(0.0f, 0.0f, 0.0f);
    glColor4f(1.0f, 0.93f, 0.7f, 0.0f);
    for (int i = 0; i <= seg; i++) {
        float a = 2.0f * PI * i / seg;
        glVertex3f(length, radius * std::cos(a), radius * std::sin(a));
    }
    glEnd();
}

}
